window.TP_DATA = {
  "aplikasi": "Aplikasi Team Pemenangan",
  "v": 1,
  "disimpan": "1970-01-01T00:00:00.000Z",
  "settings": null,
  "members": []
};
